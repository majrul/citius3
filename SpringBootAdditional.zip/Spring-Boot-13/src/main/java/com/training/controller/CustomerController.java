package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.Customer;
import com.training.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/all")
	public Iterable<Customer> getall() {
		return customerService.registeredCustomers();
	}
	

	@GetMapping("/id/{id}")
	public Customer get(@PathVariable("id") int id) {
		return customerService.customer(id);
	}
	
}
