package com.training.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.training.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	Iterable<Customer> findByEmail(String emailAddress);
	Iterable<Customer> findByFirstNameAndLastName(String firstName, String lastName);

	@Query("select c from Customer c where c.email like %?1%")
	Iterable<Customer> findByEmailAddressOf(String domain);
	
	
	@Query("select c from Customer c where c.email like %?1%")
	Page<Customer> findByEmailAddressOf(String domain, Pageable pageable);
	
	
}
