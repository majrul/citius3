package com.training.service;

import org.springframework.cache.annotation.Cacheable;

import com.training.entity.Customer;

public interface ICustomerService {

	void register(Customer customer);

	Iterable<Customer> registeredCustomers();

}