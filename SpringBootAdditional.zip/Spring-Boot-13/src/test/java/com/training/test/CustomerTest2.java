package com.training.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.training.entity.Customer;
import com.training.repository.CustomerRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
//@AutoConfigureTestDatabase(replace=Replace.NONE)
@Rollback(false)
@SpringBootTest
public class CustomerTest2 {

	@Autowired private CustomerRepository customerRepository;

	@Test
	public void testVersioning() throws Exception {
		class Transaction1 implements Runnable {
			@Override
			public void run() {
				Customer customer = customerRepository.findById(1).get();
				customer.setEmail("majrul@outlook.com");
				try { Thread.sleep(1000); } catch(Exception e) { }
				customerRepository.save(customer);
			}
		}
		class Transaction2 implements Runnable {
			@Override
			public void run() {
				Customer customer = customerRepository.findById(1).get();
				customer.setEmail("majrul@yahoo.com");
				try { Thread.sleep(500); } catch(Exception e) { }
				customerRepository.save(customer);
			}
		}
		
		Thread th1 = new Thread(new Transaction1());
		Thread th2 = new Thread(new Transaction2());
		try { th1.join(); } catch(Exception e) { }
		try { th2.join(); } catch(Exception e) { }
	}
}
