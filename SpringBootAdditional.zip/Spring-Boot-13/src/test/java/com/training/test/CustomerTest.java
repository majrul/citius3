package com.training.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.training.entity.Customer;
import com.training.repository.CustomCustomerCriteria;
import com.training.repository.CustomerRepository;
import com.training.service.ICustomerService;

@RunWith(SpringRunner.class)
@DataJpaTest
//@AutoConfigureTestDatabase(replace=Replace.NONE)
@Rollback(false)
@SpringBootTest
public class CustomerTest {

	@Autowired private ICustomerService customerService;

	@Test
	public void testSaveCustomer() throws Exception {
		Customer customer = new Customer();
		customer.setFirstName("Majrul");
		customer.setLastName("Ansari");
		customer.setEmail("majrul@gmail.com");
		
		customerService.register(customer);
	}

	@Test
	public void testFetchCustomers() throws Exception {
		Iterable<Customer> customers = customerService.registeredCustomers();
		System.out.println(customers);
		
		customers = customerService.registeredCustomers();
		System.out.println(customers);
	}
}
