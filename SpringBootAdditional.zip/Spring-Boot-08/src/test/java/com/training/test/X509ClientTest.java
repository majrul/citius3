package com.training.test;

import java.security.KeyStore;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class X509ClientTest {

	@Autowired
	private TestRestTemplate restTemplate;
	
	
	@Test
	public void testUnAuthenticatedHello() {
		ResponseEntity<String> httpsEntity = restTemplate.getForEntity("/hello", String.class);
		//assertThat((httpsEntity.getStatusCode()).isEqualTo(HttpStatus.OK)
		System.out.println(httpsEntity.getStatusCodeValue());
		System.out.println(httpsEntity.getBody());
	}

	@Test
	public void testAuthenticatedHello() throws Exception {
		restTemplate
			.getRestTemplate()
			.setRequestFactory(new HttpComponentsClientHttpRequestFactory(
					HttpClients.custom().setSSLSocketFactory(socketFactory()).build()));
		
		ResponseEntity<String> httpsEntity = restTemplate.getForEntity("/hello", String.class);
		//assertThat((httpsEntity.getStatusCode()).isEqualTo(HttpStatus.OK)
		System.out.println(httpsEntity.getStatusCodeValue());
		System.out.println(httpsEntity.getBody());
		
		/*System.setProperty("javax.net.debug", "all");
		 System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
		 System.setProperty("https.protocols", "TLSv1.2");
		 System.setProperty("javax.net.ssl.trustStore", "c://core-jks//MyClient.jks");
		 System.setProperty("javax.net.ssl.trustStorePassword", "password");
		 System.setProperty("javax.net.ssl.keyStore",  "c://core-jks//MyClient.jks");
		 System.setProperty("javax.net.ssl.keyStorePassword", "password");*/
	}
	
	private SSLConnectionSocketFactory socketFactory() throws Exception {
		char[] password = "password".toCharArray();
		KeyStore trustStore = KeyStore.getInstance("PKCS12");
		trustStore.load(new ClassPathResource("client.p12").getInputStream(), password);
		SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadKeyMaterial(trustStore,password);
		builder.loadTrustMaterial(trustStore, new TrustSelfSignedStrategy());
		return new SSLConnectionSocketFactory(builder.build(), new NoopHostnameVerifier());
		
	}
}




