package com.training.service;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.training.entity.Trade;

@Service
public class RemoteBankService {

	private final RemoteBankServiceProperties properties;
	
	private final RestTemplate restTemplate;

	public RemoteBankService(
			RemoteBankServiceProperties properties, 
			RestTemplateBuilder restTemplateBuilder) {
		this.properties = properties;
		this.restTemplate = restTemplateBuilder.build();
	}
	
	public String communicateWithBankForNewTrade(Trade trade) {
		String responseFromBank = restTemplate.postForObject(properties.getApiUri(),trade, String.class);
		return responseFromBank;
	}
	
}
