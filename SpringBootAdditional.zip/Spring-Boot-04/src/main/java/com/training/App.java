package com.training;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import com.training.service.TradeService;

@SpringBootApplication
@EnableConfigurationProperties
public class App {

	/*@Bean(autowire=Autowire.BY_TYPE)
	public TradeService tradeService() {
		return new TradeService();
	}*/
	
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}
