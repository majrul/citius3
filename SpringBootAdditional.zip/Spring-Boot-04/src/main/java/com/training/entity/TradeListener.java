package com.training.entity;

import javax.persistence.PostPersist;
import javax.persistence.PrePersist;

public class TradeListener {

	@PrePersist
	public void beforeInsert(Trade trade) {
		System.out.println("beforeInsert");
	}

	@PostPersist
	public void afterInsert(Trade trade) {
		System.out.println("afterInsert");
	}
}
