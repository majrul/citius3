package com.training.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.Trade;
import com.training.service.RemoteBankService;
import com.training.service.TradeService;

@RestController
@RequestMapping("/trade/*")
public class TradeController {

	@Autowired private TradeService tradeService;
	
	@Autowired private RemoteBankService remoteBankService;
	
	@PostMapping(path="/postNewTrade", consumes="application/json", produces="text/plain")
	public String postNewTrade(@Valid Trade trade) {
		tradeService.processNewTrade(trade);
		remoteBankService.communicateWithBankForNewTrade(trade);
		
		return "Trade record created successfully";
	}
	
}
