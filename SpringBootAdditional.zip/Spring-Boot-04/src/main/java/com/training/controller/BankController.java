package com.training.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.Trade;

@RestController
@RequestMapping("/bank/*")
public class BankController {

	@PostMapping(path="/newTradeByClient", consumes="application/json", produces="text/plain")
	public String postNewTrade(Trade trade) {
		return "Trade record acknowledged by the Bank";
	}
	
}
