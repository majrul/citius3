package com.training.test;

import static org.junit.Assert.fail;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.MockRestServiceServer;

import com.training.entity.Trade;
import com.training.service.RemoteBankService;
import com.training.service.RemoteBankServiceProperties;

@RunWith(SpringRunner.class)
@RestClientTest({ RemoteBankService.class , RemoteBankServiceProperties.class })
@TestPropertySource(properties = "rest.apiUri=http://somebank.com/bank/newTradeByClient")
public class RemoteBankServiceTest {

	@Autowired private MockRestServiceServer server;
	
	@Autowired private RemoteBankService service;
	
	@Test
	public void testRemoteBankService() {
		server.expect(
				requestTo("http://somebank.com/bank/newTradeByClient"))
				.andRespond(withSuccess("Trade record acknowledged by the bank".getBytes(), 
											MediaType.TEXT_PLAIN));
		
		Trade trade = new Trade();
		trade.setTradeId(12345);
		trade.setRegion("NY");
		trade.setDate(new Date());
		trade.setAmount(4500);
		
		String responseFromBank = service.communicateWithBankForNewTrade(trade);
		System.out.println(responseFromBank); //should be an assert instead
	}

}
