package com.training.test;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.training.entity.Customer;
import com.training.entity.Order;
import com.training.entity.Payment;
import com.training.entity.Shipment;
import com.training.service.OnlineService;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback(false)
public class TestCode {

	@Autowired
	private OnlineService onlineService;
	
	@Test
	public void testPlaceOrder() {
		Customer customer = new Customer();
		customer.setId(123);
		customer.setName("Majrul");
		customer.setEmail("majrul@gmail.com");
		
		Order order = new Order();
		order.setId(11111);
		order.setAmount(5000);
		order.setOrderDate("27-Sep-2018");
		
		Payment payment = new Payment();
		payment.setId(222);
		payment.setBankName("ICICI");
		payment.setAmount(5000);
		
		Shipment shipment = new Shipment();
		shipment.setId(1212121);
		shipment.setLogisticsPartner("BlueDart");
		shipment.setGuaranteedDeliveryBy("28-Sep-2018");
		
		onlineService.placeOrder(customer, order, payment, shipment);		
	}
}
