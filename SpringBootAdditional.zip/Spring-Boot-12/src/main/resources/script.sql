-- for Database 1

create table customer_tbl(id int, name varchar(100), email varchar(100));

create table order_tbl(id int, orderdate varchar(100), amount double);


-- for Database 2

create table payment_tbl(id int, bankname varchar(100), amount double);

create table shipment_tbl(id int, logisticspartner varchar(100), guaranteeddeliveryby varchar(100));


