package com.training.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.entity.Payment;

@Repository
public class PaymentRepository {

	@Autowired
	private JdbcTemplate db2JdbcTemplate;
	
	public void save(Payment payment) {
		db2JdbcTemplate.update("INSERT INTO PAYMENT_TBL VALUES(?,?,?)",
				payment.getId(), payment.getBankName(), payment.getAmount());
	}
}
