package com.training.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.entity.Order;

@Repository
public class OrderRepository {

	@Autowired
	private JdbcTemplate db1JdbcTemplate;
	
	public void save(Order order) {
		db1JdbcTemplate.update("INSERT INTO ORDER_TBL VALUES(?,?,?)",
				order.getId(), order.getOrderDate(), order.getAmount());
	}
}
