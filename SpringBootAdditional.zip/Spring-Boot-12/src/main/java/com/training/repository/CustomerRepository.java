package com.training.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.entity.Customer;
import com.training.entity.Payment;

@Repository
public class CustomerRepository {

	@Autowired
	private JdbcTemplate db1JdbcTemplate;
	
	public void save(Customer customer) {
		db1JdbcTemplate.update("INSERT INTO CUSTOMER_TBL VALUES(?,?,?)",
				customer.getId(), customer.getName(), customer.getEmail());
	}
}
