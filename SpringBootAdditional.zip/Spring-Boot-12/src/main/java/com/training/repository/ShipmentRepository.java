package com.training.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.entity.Shipment;

@Repository
public class ShipmentRepository {

	@Autowired
	private JdbcTemplate db2JdbcTemplate;
	
	public void save(Shipment shipment) {
		db2JdbcTemplate.update("INSERT INTO SHIPMENT_TBL VALUES(?,?,?)",
				shipment.getId(), shipment.getLogisticsPartner(), shipment.getGuaranteedDeliveryBy());
	}
}
