package com.training;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.atomikos.jdbc.AtomikosDataSourceBean;

@Configuration
public class DatabaseSetup {

	@Bean
	@ConfigurationProperties(prefix = "datasource.db1")
	public DataSource db1DataSource() {
		return new AtomikosDataSourceBean();
	}

	@Bean
	@ConfigurationProperties(prefix = "datasource.db2")
	public DataSource db2DataSource() {
		return new AtomikosDataSourceBean();
	}
	
	@Bean
	public JdbcTemplate db1JdbcTemplate() {
		return new JdbcTemplate(db1DataSource());
	}

	@Bean
	public JdbcTemplate db2JdbcTemplate() {
		return new JdbcTemplate(db2DataSource());
	}
}
