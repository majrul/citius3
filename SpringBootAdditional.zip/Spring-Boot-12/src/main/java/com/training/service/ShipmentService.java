package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.entity.Shipment;
import com.training.repository.ShipmentRepository;

@Service
@Transactional
public class ShipmentService {

	@Autowired
	private ShipmentRepository shipmentRepository;
	
	@JmsListener(destination = "ShipmentQueue")
	public void onMessage(Shipment shipment) {
		//shipmentRepository.save(shipment);
		/*if(success)
			msg.acknowledge();
		if(noOfTries == 3) {
			msg.acknowledge();
			//email*/
		
			
	}
}
