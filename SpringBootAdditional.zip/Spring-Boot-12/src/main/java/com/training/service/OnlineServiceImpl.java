package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.entity.Customer;
import com.training.entity.Order;
import com.training.entity.Payment;
import com.training.entity.Shipment;
import com.training.repository.CustomerRepository;
import com.training.repository.OrderRepository;
import com.training.repository.PaymentRepository;
import com.training.repository.ShipmentRepository;

@Service
public class OnlineServiceImpl implements OnlineService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private PaymentRepository paymentRepository;

	@Autowired
	private ShipmentRepository shipmentRepository;

	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Override
	@Transactional
	public void placeOrder(Customer customer, Order order, Payment payment, Shipment shipment) {
		customerRepository.save(customer);
		orderRepository.save(order);
		paymentRepository.save(payment);
		//shipmentRepository.save(shipment);
		jmsTemplate.convertAndSend("ShipmentQueue", shipment);
	}
}
