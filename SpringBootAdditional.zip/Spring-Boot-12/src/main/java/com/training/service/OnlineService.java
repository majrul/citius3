package com.training.service;

import com.training.entity.Customer;
import com.training.entity.Order;
import com.training.entity.Payment;
import com.training.entity.Shipment;

public interface OnlineService {

	void placeOrder(Customer customer, Order order, Payment payment, Shipment shipment);

}