package com.training.entity;

import java.io.Serializable;
import java.util.Date;

public class Shipment implements Serializable {

	private int id;
	
	private String logisticsPartner;
	private String guaranteedDeliveryBy;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLogisticsPartner() {
		return logisticsPartner;
	}
	public void setLogisticsPartner(String logisticsPartner) {
		this.logisticsPartner = logisticsPartner;
	}
	public String getGuaranteedDeliveryBy() {
		return guaranteedDeliveryBy;
	}
	public void setGuaranteedDeliveryBy(String guaranteedDeliveryBy) {
		this.guaranteedDeliveryBy = guaranteedDeliveryBy;
	}
	
	
}
