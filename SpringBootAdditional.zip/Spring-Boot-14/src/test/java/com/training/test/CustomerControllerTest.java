package com.training.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

public class CustomerControllerTest {

	@Test
	public void test() {
		RestTemplate template = new RestTemplate();
	
		LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();
		map.add("profilePic", new ClassPathResource("sample.jpg"));
		map.add("customer", "{\"name\" : \"Majrul\" , \"email\" : \"majrul@gmail.com\"}");
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		
		HttpEntity<LinkedMultiValueMap<String, Object>> requestEntity = 
										new HttpEntity<LinkedMultiValueMap<String,Object>>(map, headers);
		
		ResponseEntity<String> result = 
				template.postForEntity("http://localhost:8080/customer/new", requestEntity, String.class);
		
		System.out.println(result.getBody());
	}

}
