package com.training;

import java.util.List;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@SpringBootApplication
@EnableBatchProcessing
public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}

@Configuration
class JobConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1")
				.tasklet(new Tasklet() {
					
					@Override
					public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
						System.out.println("Hello from Spring Batch");
						return RepeatStatus.FINISHED;
					}
				}).build();
				
	}
	
	@Bean
	public Job hellWorldJob() {
		return jobBuilderFactory.get("helloWorldJob2")
				.start(step1())
				.build();
	}
	
	@Bean
	public Step messageProcessingStep() {
		return stepBuilderFactory.get("messageProcessingStep")
				.<String,String> chunk(1)
				.reader(new Reader())
				.processor(new Processor())
				.writer(new Writer())
				.build();
	}
	
	@Bean
	public Job messageProcessingJob() {
		return jobBuilderFactory.get("messageProcessingJob")
				.listener(listener())
				.start(messageProcessingStep())
				.build();
	}
	
	@Bean
	public JobExecutionListenerSupport listener() {
		return new JobCompletionListener();
	}
	
}

class Reader implements ItemReader<String> {
	
	private String[] messages = {"Java","Oracle","PHP","Python"};
	
	private int count = 0;
	
	@Override
	public String read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		if(count < messages.length)
			return messages[count++];
		else
			count = 0;
		return null;
	}
	
}

class Processor implements ItemProcessor<String, String> {
	
	@Override
	public String process(String item) throws Exception {
		return item.toUpperCase();
	}
}

class Writer implements ItemWriter<String> {
	
	@Override
	public void write(List<? extends String> items) throws Exception {
		for(String message : items)
			System.out.println(message);
	}
}

class JobCompletionListener extends JobExecutionListenerSupport {
	
	//@Autowired
	private JavaMailSender mailSender;
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		if(jobExecution.getStatus() == BatchStatus.COMPLETED) {
			System.out.println("Batch got executed succcessfully");
			SimpleMailMessage message = new SimpleMailMessage();
			message.setTo("myteam@db.com");
			message.setSubject("Batch progress");
			message.setText("Batch got executed successfully");
			//mailSender.send(message);
		}
	}
}



