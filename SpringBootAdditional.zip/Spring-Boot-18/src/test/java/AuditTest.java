import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.training.audit.Customer;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=com.training.audit.App.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Rollback(false)
public class AuditTest {

	@Autowired
	private TestEntityManager entityManager;

	@Test
	public void test1() {
		Customer c = new Customer();
		c.setName("Majrul");
		c.setEmail("majrul@gmail.com");
		entityManager.persist(c);
	}

	@Test
	public void test2() {
		Customer c = entityManager.find(Customer.class, 2);
		c.setEmail("majrul@outlook.com");
		entityManager.merge(c);
	}
	
	@Test
	public void test3() {
		AuditReader reader = AuditReaderFactory.get(entityManager.getEntityManager());
		//reader.createQuery().
		Customer c = reader.find(Customer.class, 2, 2);	
		System.out.println(c);
	}

}
