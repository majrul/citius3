package com.training.swagger;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}

	@Bean
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.training.swagger")).paths(PathSelectors.any()).build();
	}

}

@RestController
class HelloController {

	@GetMapping("/hello")
	public String hello() {
		return "Hello";
	}
}

@ApiModel(description = "Class representing a person tracked by the application.")
class Person {
	@ApiModelProperty(notes = "Unique identifier of the person. No two persons can have the same id.", example = "1", required = true, position = 0)
	private int id;
	
	@ApiModelProperty(notes = "First name of the person.", example = "John", required = true, position = 1)
	private String firstName;
	
	@ApiModelProperty(notes = "Last name of the person.", example = "Doe", required = true, position = 2)
	private String lastName;
	
	@ApiModelProperty(notes = "Age of the person. Non-negative integer", example = "42", position = 3)
	private int age;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}

@RestController
@RequestMapping("/v2/persons/")
@Api(description = "Set of endpoints for Creating, Retrieving, Updating and Deleting of Persons.")
class PersonController {

	private PersonService personService;

	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	@ApiOperation("Returns list of all Persons in the system.")
	public List getAllPersons() {
		return personService.getAllPersons();
	}

	@RequestMapping(method = RequestMethod.GET, path = "/{id}", produces = "application/json")
	@ApiOperation("Returns a specific person by their identifier. 404 if does not exist.")
	public Person getPersonById(@ApiParam("Id of the person to be obtained. Cannot be empty.") @PathVariable int id) {
		return personService.getPersonById(id);
	}

	@RequestMapping(method = RequestMethod.DELETE, path = "/{id}")
	@ApiOperation("Deletes a person from the system. 404 if the person's identifier is not found.")
	public void deletePerson(@ApiParam("Id of the person to be deleted. Cannot be empty.") @PathVariable int id) {
		personService.deletePerson(id);
	}

	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	@ApiOperation("Creates a new person.")
	public Person createPerson(
			@ApiParam("Person information for a new person to be created.") @RequestBody Person person) {
		return personService.createPerson(person);
	}

	@Autowired
	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
}

@Service
class PersonService {

	public List getAllPersons() {
		// TODO Auto-generated method stub
		return null;
	}

	public Person createPerson(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deletePerson(int id) {
		// TODO Auto-generated method stub

	}

	public Person getPersonById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
