package com.training.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}

@RestController
class CustomerController {

	@PostMapping("/add")
	public Status add(@Valid @RequestBody Customer customer) {
		Status status = new Status();
		status.setStatusMessage("Success");
		return status;
	}
}

class Status {

	private String statusMessage;

	private Map<String, String> errorsIfAny = new HashMap<>();

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public Map<String, String> getErrorsIfAny() {
		return errorsIfAny;
	}

	public void setErrorsIfAny(Map<String, String> errorsIfAny) {
		this.errorsIfAny = errorsIfAny;
	}
}

class Customer {

	@NotNull
	String name;

	@NotNull
	@Email
	@StrongEmail
	String email;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}

@Documented
@Constraint(validatedBy = StrongEmailValidator.class)
@Target({ ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@interface StrongEmail {
	String message() default "Email address cannot be of gmail/yahoo/hotmail";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};
}

class StrongEmailValidator implements ConstraintValidator<StrongEmail, String> {

	private List<String> restrictedDomains = new ArrayList<String>();

	StrongEmailValidator() {
		restrictedDomains.add("hotmail.com");
		restrictedDomains.add("yahoo.com");
		restrictedDomains.add("gmail.com");
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		String domainName = value.substring(value.indexOf("@") + 1);
		if (restrictedDomains.contains(domainName))
			return false;
		return true;
	}

}

@ControllerAdvice
class ValidationErrorHandler {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handle(MethodArgumentNotValidException ex) {
		Status status = new Status();
		status.setStatusMessage("ERROR:");

		BindingResult result = ex.getBindingResult();
		List<FieldError> fieldErrors = result.getFieldErrors();

		for (FieldError fieldError : fieldErrors)
			status.getErrorsIfAny().put(fieldError.getField(), fieldError.getDefaultMessage());

		return new ResponseEntity<Object>(status, HttpStatus.BAD_REQUEST);
	}

}
