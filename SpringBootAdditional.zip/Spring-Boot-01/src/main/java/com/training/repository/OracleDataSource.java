package com.training.repository;

public class OracleDataSource implements DataSource {

}
