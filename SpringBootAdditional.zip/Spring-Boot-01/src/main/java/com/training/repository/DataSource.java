package com.training.repository;

public interface DataSource {

}
