package com.training.repository;

public class SybaseDataSource implements DataSource {

}
