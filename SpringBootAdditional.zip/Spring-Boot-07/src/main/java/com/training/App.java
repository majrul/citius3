package com.training;

import java.security.Principal;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class App {

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}

@Component
class CreateAccounts implements CommandLineRunner {
	
	@Autowired private AccountRepository accountRepository;
	
	@Autowired PasswordEncoder passwordEncoder;
	
	@Override
	public void run(String... args) throws Exception {
		Account acc = new Account();
		acc.setActive(true);
		acc.setUsername("majrul");
		acc.setPassword(passwordEncoder.encode("123"));
		accountRepository.save(acc);
	}
}

@RestController
class HelloController {
	
	@RequestMapping(method=RequestMethod.GET, path="/hello")
	public Map<String, String> hello(Principal p) {
		return Collections.singletonMap("message", "Hello " + p.getName());
	}
	
}

@Service
class AccountDetailsService implements UserDetailsService {
	
	@Autowired private AccountRepository accountRepository;
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return accountRepository.findByUsername(username)
				.map(account -> 
						new User(username, 
								 account.getPassword(), 
								 AuthorityUtils.createAuthorityList("ROLE_ADMIN","ROLE_USER")
				))
				.orElseThrow(() ->
					new UsernameNotFoundException("couldn't find " + username));
	}
	
}

interface AccountRepository extends JpaRepository<Account, Long> {
	Optional<Account> findByUsername(String username);
}

@Entity
class Account {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private String username;
	private String password;
	private boolean active;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
	
	
}
