package com.training.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.training.entity.Customer;
import com.training.repository.CustomCustomerCriteria;
import com.training.repository.CustomerRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Rollback(false)
public class CustomerTest {

	@Autowired private CustomerRepository customerRepository;

	@Test
	public void testSaveCustomer() throws Exception {
		Customer customer = new Customer();
		customer.setFirstName("Majrul");
		customer.setLastName("Ansari");
		customer.setEmail("majrul@gmail.com");
		
		customerRepository.save(customer);
	}
	
	@Test
	public void testRefreshCustomer() throws Exception {
		Customer customer = customerRepository.findById(1).get();
		customerRepository.refresh(customer);
	}
	
	@Test
	public void testFetchCustomerBasedOnEmail() throws Exception {
		Customer customer = new Customer();
		customer.setFirstName("ABC");
		customer.setLastName("ABC");
		customer.setEmail("abc@gmail.com");
		customerRepository.save(customer);
		
		customer = new Customer();
		customer.setFirstName("DEF");
		customer.setLastName("DEF");
		customer.setEmail("def@gmail.com");
		customerRepository.save(customer);
		
		customer = new Customer();
		customer.setFirstName("Majrul");
		customer.setLastName("Ansari");
		customer.setEmail("majrul@outlook.com");
		customerRepository.save(customer);
		
		
		Iterable<Customer> custs = customerRepository.findByEmailAddressOf("gmail");
		for(Customer cust : custs)
			System.out.println(cust);
	}
	
	@Test
	public void testFetchCustomerBasedOnEmailAndPagination() throws Exception {
		long count = customerRepository.count();
		int pageSize = 5;
		long pages = count / pageSize;
		
		for(int i=0; i< pages; i++) {
			Iterable<Customer> custs = 
					//customerRepository.findByEmailAddressOf("gmail",
					customerRepository.findAll(
							PageRequest.of(i, pageSize, Sort.by("firstName").ascending()));
			for(Customer cust : custs)
				System.out.println(cust);	
		}
	}
	
	@Test
	public void testFetchCustomerBasedOnCriteria() throws Exception {
		Iterable<Customer> customers = 
				customerRepository.findAll(CustomCustomerCriteria.customersBasedOnEmail("gmail"));
		for(Customer cust : customers)
			System.out.println(cust);	
		
	}
}
