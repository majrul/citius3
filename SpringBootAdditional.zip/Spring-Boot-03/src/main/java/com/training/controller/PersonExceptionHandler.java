package com.training.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@ControllerAdvice
public class PersonExceptionHandler {

	//@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(PersonRecordMissingException.class)
	public ResponseEntity<ErrorObj> handleException(PersonRecordMissingException e) {
		//logging/email and other routine exception handling activities here
		//missing right now
		ErrorObj obj = new ErrorObj();
		obj.setErrorCode(111);
		obj.setErrorMessage("No record found for this Person");
		obj.setTimestamp(System.currentTimeMillis());
		
		return new ResponseEntity<>(obj, HttpStatus.NOT_FOUND);
	}

	
	public static class ErrorObj {
		
		private int errorCode;
		private String errorMessage;
		private long timestamp;
		
		public int getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(int errorCode) {
			this.errorCode = errorCode;
		}
		public String getErrorMessage() {
			return errorMessage;
		}
		public void setErrorMessage(String errorMessage) {
			this.errorMessage = errorMessage;
		}
		public long getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(long timestamp) {
			this.timestamp = timestamp;
		}
	
		
	}
}
