package com.training.controller;

public class PersonRecordMissingException extends RuntimeException {

}
