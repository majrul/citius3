package com.training.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.Address;
import com.training.entity.Person;

@RestController
@RequestMapping("/person/*")
public class PersonController {

	//@Autowired
	//private ModelMapper modelMapper;
	
	@GetMapping(path="/email/{email}", produces = {"application/json"})
	public Person get(@PathVariable("email") String email) {
		//code to access some repository missing right now
		//assume we are pulling the Person details from the DB
		//which returns a Person object
		Person person = new Person();
		person.setName("Majrul");
		person.setEmail("majrul@gmail.com");
		Address address = new Address();
		address.setCity("Mumbai");
		address.setPincode("400083");
		person.setAddress(address);
		//return person;
		
		throw new PersonRecordMissingException();
		//return modelMapper.map(person, PersonDTO.class);
	}
	
}
