package com.project;

import java.util.List;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ConditionalOnClass(ModelMapper.class)
public class ModelMapperConfiguration {

	private List<PropertyMap<?, ?>> mappings;
	
	//private List<Converter<?, ?>> converters;

	//we are actually using Constructor injection
	//no need of @Autowired
	@Autowired
	public ModelMapperConfiguration(
			ObjectProvider<List<PropertyMap<?, ?>>> mappings) { 
			//ObjectProvider<List<Converter<?, ?>>> converters) {
		System.out.println("MpdelMapper constr..");
		this.mappings = mappings.getIfAvailable();
		//this.converters = converters.getIfAvailable();
	}
	
	@Bean
	//@ConditionalOnMissingBean
	public ModelMapper modelMapper() {
		ModelMapper mapper = new ModelMapper();
		
		for(PropertyMap<?, ?> mapping : mappings)
			mapper.addMappings(mapping);
		
		//for(Converter<?, ?> converter : converters)
		//	mapper.addConverter(converter);
		
		return mapper;
	}
	
	
}
