package com.training.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.entity.Person;

import static org.assertj.core.api.Assertions.*;

@RunWith(SpringRunner.class)
@JsonTest
public class PersonJSONTest {

	@Autowired
	private JacksonTester<Person> json;

	/*@Test
	public void testSerialize() throws Exception {
		String expectedJson = "{\"nameOfThePerson\":\"Majrul\",\"emailAddress\":\"majrul@gmail.com\"}";
				Person person = new Person("Majrul", "majrul@gmail.com");
		ObjectMapper mapper = new ObjectMapper();
		String generatedJson = mapper.writeValueAsString(person);
		assertEquals(expectedJson, generatedJson);
		//assertThat(this.json.write(person)).isEqualToJson("expected.json");
	}*/

}
