package com.training.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Component
@Aspect
public class LoggingAspect {

	@Before("execution(public * apply*(..))")
	public void log(JoinPoint joinPoint) {
		System.out.println("common logging code executed for : "+joinPoint);
		Object[] args = joinPoint.getArgs();
		for(Object arg : args)
			System.out.println(arg);
	}	
	
	@AfterReturning(value="execution(public * balance(..)", returning = "var")
	public void doSomething(double var) {
		
	}
	
	@Around("execution(public * *(..))")
	public Object log(ProceedingJoinPoint jp) throws Throwable {
		StopWatch watch = new StopWatch();
		Object retVal = null;
		try {
			watch.start();
			retVal = jp.proceed();
			watch.stop();
		}
		finally {
			watch.prettyPrint();
		}
		return retVal;
	}
}
