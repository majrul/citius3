package com.training.service;

import java.io.Serializable;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

@Service
@ManagedResource(objectName = ":name=customerservice", description="This is an important Service")
public class CustomerServiceImpl implements CustomerService, Serializable {

	public void applyForChequeBook(long acno) {
		System.out.println("applyForChequeBook method called..");
	}
	
	public void stopCheque(long acno) {
		System.out.println("stopCheque method called..");
	}
	
	public void applyForCreditCard(String name, double salary) {
		System.out.println("applyForCreditCard method called..");
	}
	
	@ManagedOperation(description = "This is an important method")
	public double balance(long acno) {
		System.out.println("balance method called..");
		return 9999.9;
	}
}
