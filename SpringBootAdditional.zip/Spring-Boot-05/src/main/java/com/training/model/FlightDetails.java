package com.training.model;

public class FlightDetails {

	//private List<Flight> flights;
}
