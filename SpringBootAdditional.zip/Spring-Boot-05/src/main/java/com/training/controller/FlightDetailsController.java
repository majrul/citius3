package com.training.controller;

import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;

import com.training.model.FlightDetails;
import com.training.service.AirlinesService;

@RestController
public class FlightDetailsController {

	@Autowired private AirlinesService airlinesService;
	
	@GetMapping(path = "/getAvailableFlights/{source}/{destination}")
	public DeferredResult<FlightDetails> get(@PathVariable("source") String source,
							 @PathVariable("destination") String destination) {
		
		DeferredResult<FlightDetails> result = new DeferredResult<FlightDetails>(15000l);
		
		//new Thread() -> run() -> airlinesService.getAvailableFlights(source,destination);
		ForkJoinPool.commonPool().submit(() -> {
			FlightDetails flightDetails = airlinesService.getAvailableFlights(source,destination);
			result.setResult(flightDetails);
		});

		result.onTimeout(() -> {
			result.setErrorResult(ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body("Request timedout"));
		});
		
		//return airlinesService.getAvailableFlights(source,destination);
		return result;
	}
	
	
}
