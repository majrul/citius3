package com.majrul.locking;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import com.majrul.util.JPAUtil;

public class LockingTest {

	public static void main(String[] args) {
		TestSession1 s1 = new TestSession1();
		TestSession2 s2 = new TestSession2();
		new Thread(s1).start();
		new Thread(s2).start();
	}

	static class TestSession1 implements Runnable {
	
		public void run() {
			try {
				Thread.sleep(1000);
				EntityManagerFactory entityManagerFactory = JPAUtil.getEntityManagerFactory();
				EntityManager entityManager = entityManagerFactory.createEntityManager();
				EntityTransaction tx = entityManager.getTransaction();
				tx.begin();
				
				Product p = entityManager.find(Product.class, 1);
				System.out.println("Thread-1: Version " + p.getVersion() + " before update");
								
				p.setPrice(p.getPrice() + 10);
	
				tx.commit();
				entityManager.close();
				System.out.println("Thread-1: Version " + p.getVersion() + " after update");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	static class TestSession2 implements Runnable {
	
		public void run() {
			try {
				Thread.sleep(500);
				EntityManagerFactory entityManagerFactory = JPAUtil.getEntityManagerFactory();
				EntityManager entityManager = entityManagerFactory.createEntityManager();
				EntityTransaction tx = entityManager.getTransaction();
				tx.begin();
	
				Product p = entityManager.find(Product.class, 1);
				System.out.println("Thread-2: Version " + p.getVersion() + " before update");
	
				Thread.sleep(1000);		
				
				p.setPrice(p.getPrice() + 10);
	
				tx.commit();
				entityManager.close();
				System.out.println("Thread-2: Version " + p.getVersion() + " after update");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}