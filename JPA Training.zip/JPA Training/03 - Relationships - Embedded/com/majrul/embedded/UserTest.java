package com.majrul.embedded;

import org.junit.Test;

import com.majrul.util.BaseDao;

public class UserTest {

	@Test
	public void testCase1() { 
		User  u = new User();
		u.setFirstname("Majrul");
		u.setLastname("Ansari");
		u.setUsername("majrul");
		u.setPassword("majrul123");
		
		Address address = new Address();
		address.setCity("Mumbai");
		address.setStreet("Vikhroli");
		address.setZipcode("400083");

		u.setBillingAddress(address);

		BaseDao dao = new BaseDao();
		dao.merge(u);
	}
}
