package com.majrul.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {

	private static EntityManagerFactory entityManagerFactory;
	
	static {
		entityManagerFactory = Persistence.createEntityManagerFactory("Hibernate-JPA");//META-INF/persistence.xml
				
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				entityManagerFactory.close();
			}
		});

	}
	
	public static EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}
}
