package com.majrul.listener;

public class AccountException extends RuntimeException {

	public AccountException() {
	}

	public AccountException(String message) {
		super(message);
	}

	
}
