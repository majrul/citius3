package com.majrul.onetomanybi;

import org.junit.Test;

import com.majrul.util.BaseDao;

public class AddEmpDeptTest {

	@Test
	public void testCase1() {
		
		Department dept = new Department();
		dept.setDeptno(10);
		dept.setName("Admin");
		dept.setLocation("Andheri, Mumbai");

		BaseDao dao = new BaseDao();
		dao.merge(dept);
	}

	@Test
	public void testCase2() {
		BaseDao dao = new BaseDao();

		Department dept = (Department) dao.find(Department.class, 10);
		Employee emp = new Employee();
		emp.setEmpno(1001);
		emp.setName("Majrul Ansari");
		emp.setSalary(1000.0);
		emp.setDept(dept);
		
		dao.merge(emp);
	}
	
	@Test
	public void testCase3() {
		BaseDao dao = new BaseDao();
		Department dept = (Department) dao.find(Department.class, 10);
	}
}





